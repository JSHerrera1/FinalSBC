from flask import Flask, render_template, request
from fetchTerm import fetchTerm

app = Flask(__name__)


@app.get('/')
def index():

    context = {
        'title': 'Buscador de terminos',
        'content': 'Sistemas Basdos en el Conocimiento - 2022'
    }

    return render_template('index.html', **context)


@app.post('/search')
def search():
    term = request.form['term']
    responses = fetchTerm(term)

    context = {
        'title': 'Buscador de terminos',
        'content': f'Resultados de la busqueda: {term}',
        'responses': responses
    }

    return render_template('search.html', **context)


app.run(host='', port=8080, debug=True)
